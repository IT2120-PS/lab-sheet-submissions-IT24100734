setwd("C:\\Users\\Desktop\\PS Lab 04")
getwd
#1
branch_data <- read.csv("Exercise.txt", header = TRUE)
str(branch_data)
#2
boxplot(branch_data$Sales_X1, main= "Boxplot of Sales", outline= TRUE,outpch= 8, horizonal = TRUE)
#3
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
#4
find_outliers <- function(X) {
  Q1 <- quantile(X, 0.25)
  Q3 <- quantile(X, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
print(paste("Upper Bownd : ",ub))
print(paste("Lower Bownd : ",lb))
print(paste(" Outliers : ",paste(sort(z[z < lb | z > ub]), collapse = ",")))
}
get.outliers(branch_data$Years_x3)

